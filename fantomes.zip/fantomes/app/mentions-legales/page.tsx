import type { Metadata } from "next";
import LegalPage, { Champ } from "@/components/LegalPage";
import { site } from "@/lib/site";

export const metadata: Metadata = { title: "Mentions légales" };

export default function MentionsLegales() {
  const e = site.editeur;
  return (
    <LegalPage titre="Mentions légales">
      <h2>Éditeur du site</h2>
      <ul>
        <li>Nom : <Champ>{e.nomComplet}</Champ></li>
        <li>Statut : <Champ>{e.statut}</Champ></li>
        <li>SIRET : <Champ>{e.siret}</Champ></li>
        <li>Adresse : <Champ>{e.adresse}</Champ></li>
        <li>E-mail : <Champ>{e.email}</Champ></li>
        <li>TVA : <Champ>{e.tva}</Champ></li>
      </ul>
      <p>Directeur de la publication : l'éditeur ci-dessus.</p>

      <h2>Hébergeur</h2>
      <p>
        {site.hebergeur.nom}, {site.hebergeur.adresse}.
      </p>

      <h2>Propriété intellectuelle</h2>
      <p>
        Les textes, la mise en page et les éléments graphiques du site sont la propriété de
        l'éditeur. Toute reproduction sans autorisation est interdite.
      </p>

      <h2>Contact</h2>
      <p>
        Pour toute question, écris à <Champ>{e.email}</Champ>.
      </p>
    </LegalPage>
  );
}
