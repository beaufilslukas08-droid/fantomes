import type { Metadata } from "next";
import LegalPage, { Champ } from "@/components/LegalPage";
import { euros, site } from "@/lib/site";

export const metadata: Metadata = { title: "Conditions générales de vente" };

export default function Cgv() {
  const e = site.editeur;
  return (
    <LegalPage titre="Conditions générales de vente">
      <p>Dernière mise à jour : 27 octobre 2026.</p>

      <h2>1. Vendeur</h2>
      <p>
        Le service {site.nom} est proposé par <Champ>{e.nomComplet}</Champ>, <Champ>{e.statut}</Champ>,
        SIRET <Champ>{e.siret}</Champ>, <Champ>{e.adresse}</Champ>. Contact : <Champ>{e.email}</Champ>.
      </p>

      <h2>2. Service vendu</h2>
      <p>
        {site.nom} est un outil en ligne qui analyse un relevé bancaire fourni par l'utilisateur,
        repère les prélèvements réguliers, les classe par coût annuel et génère une lettre de
        résiliation pour chacun. {site.nom} ne résilie aucun abonnement à la place de l'utilisateur
        et ne garantit pas qu'un prestataire acceptera une résiliation.
      </p>

      <h2>3. Prix et paiement</h2>
      <p>
        L'audit complet coûte {euros(site.prix)} TTC, payable une seule fois par carte bancaire via
        Stripe. Il n'y a ni abonnement ni reconduction automatique. <Champ>{e.tva}</Champ>
      </p>

      <h2>4. Livraison</h2>
      <p>
        L'accès au résultat complet est ouvert immédiatement après la confirmation du paiement.
      </p>

      <h2>5. Garantie satisfait ou remboursé</h2>
      <p>
        Pendant {site.garantieJours} jours après l'achat, l'utilisateur peut demander le
        remboursement intégral, sans avoir à se justifier, en écrivant à <Champ>{e.email}</Champ>.
        Le remboursement est effectué sous {site.remboursementJours} jours ouvrés sur le moyen de
        paiement utilisé.
      </p>

      <h2>6. Droit de rétractation</h2>
      <p>
        Conformément au Code de la consommation, le consommateur dispose d'un délai de 14 jours pour
        se rétracter d'un achat à distance. La garantie du point 5, plus longue, s'applique dans
        tous les cas.
      </p>

      <h2>7. Responsabilité</h2>
      <p>
        L'analyse repose sur les données du relevé fourni. {site.nom} s'efforce de repérer tous les
        prélèvements réguliers mais ne peut garantir l'exhaustivité du résultat. L'utilisateur
        vérifie chaque ligne avant de résilier.
      </p>

      <h2>8. Données personnelles</h2>
      <p>
        Le traitement des données est décrit dans la{" "}
        <a className="underline underline-offset-4" href="/confidentialite">
          politique de confidentialité
        </a>
        .
      </p>

      <h2>9. Médiation et droit applicable</h2>
      <p>
        Les présentes conditions sont soumises au droit français. En cas de litige, le consommateur
        peut recourir gratuitement à un médiateur de la consommation :{" "}
        <Champ>À COMPLÉTER : nom et site du médiateur dont tu relèves</Champ>.
      </p>
    </LegalPage>
  );
}
