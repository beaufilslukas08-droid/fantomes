import Link from "next/link";

export default function NotFound() {
  return (
    <main className="mx-auto flex min-h-screen max-w-3xl flex-col justify-center px-5 py-12">
      <p className="font-titre text-7xl font-semibold text-tampon">404</p>
      <h1 className="mt-4 font-titre text-4xl font-semibold leading-tight">
        Cette page a disparu, comme un abonnement bien résilié.
      </h1>
      <p className="mt-4 text-xl text-doux">
        L'adresse est peut-être mal écrite, ou la page n'existe plus.
      </p>
      <Link
        href="/"
        className="mt-8 inline-flex min-h-14 w-full items-center justify-center rounded-xl bg-encre px-8 text-lg font-semibold text-papier md:w-auto"
      >
        Retour à l'accueil
      </Link>
    </main>
  );
}
