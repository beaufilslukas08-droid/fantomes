import type { Metadata, Viewport } from "next";
import { Fraunces, Instrument_Sans } from "next/font/google";
import { Analytics } from "@vercel/analytics/next";
import "./globals.css";
import { site } from "@/lib/site";

const fraunces = Fraunces({
  subsets: ["latin"],
  variable: "--font-fraunces",
  display: "swap",
});

const instrument = Instrument_Sans({
  subsets: ["latin"],
  variable: "--font-instrument",
  display: "swap",
});

const titre = `${site.nom} : retrouve les abonnements que tu paies sans t'en servir`;
const description =
  "Dépose ton relevé bancaire : Fantômes repère les prélèvements oubliés, les classe par coût annuel et écrit les lettres de résiliation. Tes données restent sur ton téléphone.";

export const metadata: Metadata = {
  metadataBase: new URL(site.url),
  title: { default: titre, template: `%s · ${site.nom}` },
  description,
  openGraph: {
    title: titre,
    description,
    siteName: site.nom,
    locale: "fr_FR",
    type: "website",
  },
  twitter: { card: "summary_large_image", title: titre, description },
};

export const viewport: Viewport = {
  themeColor: "#f5efe3",
  width: "device-width",
  initialScale: 1,
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="fr" className={`${fraunces.variable} ${instrument.variable}`}>
      <body>
        {children}
        <Analytics />
      </body>
    </html>
  );
}
