import Link from "next/link";
import Footer from "@/components/Footer";
import StickyCta from "@/components/StickyCta";
import { euros, site } from "@/lib/site";

// Exemple illustratif : montants mensuels -> coût annuel (x 12).
const exemple = [
  { nom: "Service de streaming vidéo", mois: 13.99 },
  { nom: "Salle de sport jamais utilisée", mois: 29.9 },
  { nom: "Appli de méditation d'un essai gratuit", mois: 9.99 },
];
const totalExemple = exemple.reduce((s, l) => s + l.mois * 12, 0);

const faq = [
  {
    q: "Est-ce que ça marche pour mon cas ?",
    r: "Si ta banque te permet d'exporter ton relevé au format CSV (la plupart le font, dans l'espace client, rubrique « Mes comptes » ou « Télécharger »), oui. Fantômes repère les prélèvements qui reviennent à intervalle régulier, quel que soit le service.",
  },
  {
    q: "Combien de temps ça me prend ?",
    r: "Environ cinq minutes : tu déposes ton relevé, tu lis la liste, tu choisis ce que tu veux arrêter, puis tu envoies les lettres.",
  },
  {
    q: "Qu'est-ce qui se passe si je veux arrêter ?",
    r: `Rien à arrêter : tu paies ${euros(site.prix)} une seule fois, sans abonnement caché. Et si le résultat ne te convainc pas, tu es remboursé (voir la garantie ci-dessus).`,
  },
  {
    q: "À quoi sert exactement ce que je paie ?",
    r: "À la liste complète de tes abonnements oubliés, classée du plus coûteux au moins coûteux sur l'année, et à une lettre de résiliation prête à envoyer pour chacun. Fantômes ne résilie rien à ta place : c'est toi qui gardes la main.",
  },
];

export default function Accueil() {
  return (
    <>
      <main>
        {/* 1. Promesse */}
        <section className="mx-auto max-w-3xl px-5 pb-10 pt-8 md:pt-14">
          <p className="font-titre text-2xl font-semibold">{site.nom}</p>
          <h1 className="mt-8 font-titre text-[2.6rem] font-semibold leading-[1.05] tracking-tight md:text-6xl">
            Retrouve les abonnements que tu paies{" "}
            <span className="barre">sans t'en servir</span>.
          </h1>
          <p className="mt-6 max-w-xl text-xl text-doux">
            Dépose ton relevé bancaire. En quelques minutes, tu vois ce qui sort de ton compte
            sans rien t'apporter, et tu as la lettre pour l'arrêter.
          </p>
          <Link
            href="/analyse"
            className="mt-8 hidden min-h-14 items-center justify-center rounded-xl bg-encre px-8 text-lg font-semibold text-papier hover:bg-sapin md:inline-flex"
          >
            Commencer, c'est gratuit
          </Link>
          <p className="mt-4 text-sm text-doux">
            Gratuit pour voir tes premiers résultats. Ton relevé reste sur ton appareil.
          </p>
        </section>

        {/* 2. La douleur, chiffrée */}
        <section className="bg-encre px-5 py-12 text-papier">
          <div className="mx-auto max-w-3xl">
            <p className="font-titre text-5xl font-semibold leading-none text-[#ff8a75] md:text-7xl">
              {euros(9.99 * 12)} par an
            </p>
            <p className="mt-4 max-w-xl text-xl">
              C'est ce que coûte un seul abonnement de 9,99 € par mois qu'on a oublié. Petit sur un
              relevé, énorme sur une année. Et il est rarement seul.
            </p>
          </div>
        </section>

        {/* Exemple */}
        <section className="mx-auto max-w-3xl px-5 py-12">
          <h2 className="font-titre text-3xl font-semibold leading-tight">
            Voilà à quoi ressemble ta liste
          </h2>
          <p className="mt-2 text-sm text-doux">Exemple illustratif, classé par coût annuel.</p>
          <ul className="mt-6 divide-y divide-trait rounded-2xl border border-trait bg-papier-fonce/50">
            {exemple.map((l) => (
              <li key={l.nom} className="flex items-baseline justify-between gap-4 px-4 py-4">
                <div>
                  <p className="barre font-medium">{l.nom}</p>
                  <p className="text-sm text-doux">{euros(l.mois)} par mois</p>
                </div>
                <p className="font-titre text-2xl font-semibold text-tampon">
                  {euros(Math.round(l.mois * 12 * 100) / 100)}
                  <span className="text-sm font-normal text-doux"> /an</span>
                </p>
              </li>
            ))}
            <li className="flex items-baseline justify-between gap-4 bg-sapin px-4 py-4 text-papier">
              <p className="font-medium">Économie possible sur l'année</p>
              <p className="font-titre text-3xl font-semibold">
                {euros(Math.round(totalExemple * 100) / 100)}
              </p>
            </li>
          </ul>
        </section>

        {/* 3. Trois bénéfices */}
        <section className="mx-auto max-w-3xl px-5 pb-12">
          <ul className="grid gap-4 md:grid-cols-3">
            {[
              {
                t: "Tu vois tout",
                d: "Les prélèvements qui reviennent chaque mois sont repérés pour toi, même les plus petits.",
              },
              {
                t: "Tu vois ce que ça coûte vraiment",
                d: "Chaque ligne est classée par montant sur l'année, pas par mois. On regarde d'abord ce qui pèse le plus.",
              },
              {
                t: "Tu arrêtes en un envoi",
                d: "Une lettre de résiliation est prête pour chaque abonnement. Tu la copies, tu l'envoies, c'est fini.",
              },
            ].map((b) => (
              <li key={b.t} className="rounded-2xl border border-trait p-5">
                <h3 className="font-titre text-xl font-semibold leading-snug">{b.t}</h3>
                <p className="mt-2 text-doux">{b.d}</p>
              </li>
            ))}
          </ul>
        </section>

        {/* Offre + garantie */}
        <section id="offre" className="bg-papier-fonce px-5 py-12">
          <div className="mx-auto max-w-3xl">
            <h2 className="font-titre text-3xl font-semibold leading-tight">
              Un audit complet, {euros(site.prix)}, une seule fois
            </h2>
            <p className="mt-3 text-xl text-doux">
              Moins cher qu'un seul mois de la plupart des abonnements qu'on y retrouve.
            </p>
            <div className="mt-6 rounded-2xl border-2 border-sapin bg-papier p-5">
              <p className="font-titre text-xl font-semibold text-sapin">
                Satisfait ou remboursé, {site.garantieJours} jours
              </p>
              <p className="mt-2">
                Si le résultat ne te sert à rien, écris-nous dans les {site.garantieJours} jours
                suivant ton achat : tu es remboursé sous {site.remboursementJours} jours ouvrés, sans
                avoir à te justifier.
              </p>
            </div>
            <p className="mt-6 text-sm text-doux">
              Paiement unique, sans engagement, sans abonnement caché.
            </p>
            {site.lienPaiement ? (
              <a
                href={site.lienPaiement}
                className="mt-4 inline-flex min-h-14 w-full items-center justify-center rounded-xl bg-sapin px-8 text-lg font-semibold text-papier md:w-auto"
              >
                Obtenir mon audit, {euros(site.prix)}
              </a>
            ) : (
              <p className="mt-4 rounded-xl border border-dashed border-doux px-4 py-3 text-sm text-doux">
                Le paiement ouvre très bientôt.
              </p>
            )}
          </div>
        </section>

        {/* FAQ */}
        <section className="mx-auto max-w-3xl px-5 py-12">
          <h2 className="font-titre text-3xl font-semibold">Questions fréquentes</h2>
          <div className="mt-6 divide-y divide-trait border-y border-trait">
            {faq.map((f) => (
              <details key={f.q} className="group py-4">
                <summary className="flex min-h-11 cursor-pointer list-none items-center justify-between gap-4 font-medium [&::-webkit-details-marker]:hidden">
                  {f.q}
                  <span aria-hidden className="text-2xl text-doux transition group-open:rotate-45">
                    +
                  </span>
                </summary>
                <p className="mt-2 text-doux">{f.r}</p>
              </details>
            ))}
          </div>
        </section>

        {/* Dernier appel */}
        <section className="mx-auto max-w-3xl px-5 pb-12">
          <p className="font-titre text-3xl font-semibold leading-tight">
            Ça prend cinq minutes, et c'est gratuit pour commencer.
          </p>
          <Link
            href="/analyse"
            className="mt-6 inline-flex min-h-14 items-center justify-center rounded-xl bg-encre px-8 text-lg font-semibold text-papier hover:bg-sapin"
          >
            Commencer, c'est gratuit
          </Link>
        </section>
      </main>
      <Footer />
      <StickyCta />
    </>
  );
}
