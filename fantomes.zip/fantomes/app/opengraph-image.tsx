import { ImageResponse } from "next/og";

export const alt = "Fantômes : retrouve les abonnements que tu paies sans t'en servir";
export const size = { width: 1200, height: 630 };
export const contentType = "image/png";

export default function Image() {
  return new ImageResponse(
    (
      <div
        style={{
          width: "100%",
          height: "100%",
          display: "flex",
          flexDirection: "column",
          justifyContent: "space-between",
          background: "#f5efe3",
          color: "#17171a",
          padding: "72px",
          fontFamily: "Georgia, serif",
        }}
      >
        <div style={{ fontSize: 44, fontWeight: 700 }}>Fantômes</div>
        <div
          style={{
            display: "flex",
            flexWrap: "wrap",
            fontSize: 84,
            fontWeight: 700,
            lineHeight: 1.05,
          }}
        >
          <span style={{ marginRight: 20 }}>Retrouve les abonnements que tu paies</span>
          <span style={{ textDecoration: "line-through", color: "#c4301c" }}>
            sans t'en servir.
          </span>
        </div>
        <div style={{ fontSize: 32, color: "#5b574e" }}>
          Dépose ton relevé. Vois ce que ça coûte vraiment. Arrête en un envoi.
        </div>
      </div>
    ),
    size,
  );
}
