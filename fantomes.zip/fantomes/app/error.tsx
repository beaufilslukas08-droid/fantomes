"use client";

import Link from "next/link";

export default function Erreur({ reset }: { error: Error; reset: () => void }) {
  return (
    <main className="mx-auto flex min-h-screen max-w-3xl flex-col justify-center px-5 py-12">
      <h1 className="font-titre text-4xl font-semibold leading-tight">
        Quelque chose s'est mal passé.
      </h1>
      <p className="mt-4 text-xl text-doux">
        Ce n'est pas de ta faute. Si tu étais en train de payer, rien n'a été débité sans que tu le
        voies : vérifie ton e-mail de confirmation, et écris-nous au moindre doute.
      </p>
      <div className="mt-8 flex flex-col gap-3 md:flex-row">
        <button
          onClick={() => reset()}
          className="min-h-14 rounded-xl bg-encre px-8 text-lg font-semibold text-papier"
        >
          Réessayer
        </button>
        <Link
          href="/"
          className="inline-flex min-h-14 items-center justify-center rounded-xl border border-encre px-8 text-lg font-semibold"
        >
          Retour à l'accueil
        </Link>
      </div>
    </main>
  );
}
