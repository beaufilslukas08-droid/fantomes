import type { Metadata } from "next";
import Link from "next/link";
import Footer from "@/components/Footer";

export const metadata: Metadata = {
  title: "Analyse de ton relevé",
  description: "Dépose ton relevé bancaire et retrouve tes abonnements oubliés.",
};

export default function Analyse() {
  return (
    <>
      <main className="mx-auto flex min-h-[70vh] max-w-3xl flex-col justify-center px-5 py-12">
        <p className="font-titre text-xl font-semibold">Fantômes</p>
        <h1 className="mt-6 font-titre text-4xl font-semibold leading-tight">
          L'analyse gratuite ouvre très bientôt.
        </h1>
        <p className="mt-4 max-w-xl text-xl text-doux">
          On termine l'outil qui lit ton relevé et repère tes abonnements oubliés. Reviens dans
          quelques jours.
        </p>
        <Link
          href="/"
          className="mt-8 inline-flex min-h-14 w-full items-center justify-center rounded-xl bg-encre px-8 text-lg font-semibold text-papier md:w-auto"
        >
          Retour à l'accueil
        </Link>
      </main>
      <Footer />
    </>
  );
}
