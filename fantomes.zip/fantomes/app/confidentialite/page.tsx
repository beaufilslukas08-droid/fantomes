import type { Metadata } from "next";
import LegalPage, { Champ } from "@/components/LegalPage";
import { site } from "@/lib/site";

export const metadata: Metadata = { title: "Politique de confidentialité" };

export default function Confidentialite() {
  const e = site.editeur;
  return (
    <LegalPage titre="Politique de confidentialité">
      <p>Dernière mise à jour : 27 octobre 2026.</p>

      <h2>Responsable du traitement</h2>
      <p>
        <Champ>{e.nomComplet}</Champ>, <Champ>{e.adresse}</Champ>. Contact : <Champ>{e.email}</Champ>.
      </p>

      <h2>Ton relevé bancaire</h2>
      <p>
        L'analyse de ton relevé s'effectue dans ton navigateur, sur ton appareil. Le fichier n'est
        pas envoyé à nos serveurs et n'est pas conservé.
      </p>

      <h2>Les données que nous traitons</h2>
      <ul>
        <li>
          Les informations de paiement, traitées directement par Stripe. Nous ne voyons ni ne
          conservons ton numéro de carte.
        </li>
        <li>Ton adresse e-mail, si tu la fournis lors du paiement, pour t'envoyer ton reçu.</li>
        <li>
          Des statistiques de fréquentation anonymes (Vercel Analytics), sans cookie et sans
          identification personnelle.
        </li>
      </ul>

      <h2>Durée de conservation</h2>
      <p>
        Les données de facturation sont conservées pendant la durée légale applicable aux
        obligations comptables. Les statistiques sont agrégées et anonymes.
      </p>

      <h2>Tes droits</h2>
      <p>
        Tu peux demander l'accès, la rectification ou la suppression de tes données en écrivant à{" "}
        <Champ>{e.email}</Champ>. Tu peux aussi introduire une réclamation auprès de la CNIL
        (cnil.fr).
      </p>

      <h2>Prestataires</h2>
      <ul>
        <li>Stripe, pour le paiement.</li>
        <li>Vercel, pour l'hébergement et les statistiques de fréquentation.</li>
      </ul>
    </LegalPage>
  );
}
