// Toutes les informations à compléter sont ici, au même endroit.
// Remplace les valeurs « À COMPLÉTER » par les tiennes, puis enregistre.

export const site = {
  nom: "Fantômes",
  promesse: "Retrouve les abonnements que tu paies sans t'en servir.",
  url:
    process.env.NEXT_PUBLIC_SITE_URL ??
    (process.env.VERCEL_PROJECT_PRODUCTION_URL
      ? `https://${process.env.VERCEL_PROJECT_PRODUCTION_URL}`
      : "http://localhost:3000"),

  // Prix de l'audit, en euros, une seule fois.
  prix: 19,

  // Garantie : durée en jours et délai de remboursement en jours ouvrés.
  garantieJours: 30,
  remboursementJours: 5,

  // Lien de paiement Stripe (mode test d'abord). Laisse vide tant que tu ne l'as pas créé.
  lienPaiement: process.env.NEXT_PUBLIC_STRIPE_LINK ?? "",

  // Informations légales : à compléter avant toute vraie vente.
  editeur: {
    nomComplet: "À COMPLÉTER : ton prénom et ton nom",
    statut: "À COMPLÉTER : micro-entrepreneur / entrepreneur individuel",
    siret: "À COMPLÉTER : numéro SIRET (14 chiffres)",
    adresse: "À COMPLÉTER : adresse postale professionnelle",
    email: "À COMPLÉTER : adresse e-mail de contact",
    tva: "À COMPLÉTER : « TVA non applicable, art. 293 B du CGI » si tu es en franchise de TVA",
  },
  hebergeur: {
    nom: "Vercel Inc.",
    adresse: "440 N Barranca Ave #4133, Covina, CA 91723, États-Unis",
  },
};

export function euros(n: number) {
  return new Intl.NumberFormat("fr-FR", {
    style: "currency",
    currency: "EUR",
    minimumFractionDigits: Number.isInteger(n) ? 0 : 2,
  }).format(n);
}
