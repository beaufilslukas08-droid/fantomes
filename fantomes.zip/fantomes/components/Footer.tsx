import Link from "next/link";
import { site } from "@/lib/site";

export default function Footer() {
  return (
    <footer className="border-t border-trait px-5 pb-28 pt-10 text-sm text-doux md:pb-12">
      <div className="mx-auto flex max-w-3xl flex-col gap-6 md:flex-row md:items-start md:justify-between">
        <div>
          <p className="font-titre text-xl font-semibold text-encre">{site.nom}</p>
          <p className="mt-1 max-w-xs">
            Un outil pour reprendre la main sur tes abonnements.
          </p>
        </div>
        <nav aria-label="Informations légales">
          <ul className="flex flex-col gap-2">
            <li>
              <Link className="underline underline-offset-4" href="/mentions-legales">
                Mentions légales
              </Link>
            </li>
            <li>
              <Link className="underline underline-offset-4" href="/cgv">
                Conditions générales de vente
              </Link>
            </li>
            <li>
              <Link className="underline underline-offset-4" href="/confidentialite">
                Politique de confidentialité
              </Link>
            </li>
          </ul>
        </nav>
      </div>
    </footer>
  );
}
