import Link from "next/link";
import Footer from "./Footer";

export default function LegalPage({
  titre,
  children,
}: {
  titre: string;
  children: React.ReactNode;
}) {
  return (
    <>
      <main className="mx-auto max-w-3xl px-5 pb-16 pt-8">
        <Link href="/" className="text-sm text-doux underline underline-offset-4">
          ← Retour à l'accueil
        </Link>
        <h1 className="mt-6 font-titre text-4xl font-semibold leading-tight">{titre}</h1>
        <div className="mt-8 space-y-4 [&_h2]:mt-10 [&_h2]:font-titre [&_h2]:text-2xl [&_h2]:font-semibold [&_ul]:list-disc [&_ul]:space-y-1 [&_ul]:pl-6">
          {children}
        </div>
      </main>
      <Footer />
    </>
  );
}

// Champ à compléter, bien visible tant qu'il n'est pas rempli.
export function Champ({ children }: { children: React.ReactNode }) {
  const aCompleter = String(children).includes("À COMPLÉTER");
  return aCompleter ? (
    <mark className="rounded bg-tampon/15 px-1 font-medium text-tampon">{children}</mark>
  ) : (
    <>{children}</>
  );
}
