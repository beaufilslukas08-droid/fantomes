import Link from "next/link";

// Bouton fixé en bas de l'écran sur téléphone : atteignable au pouce.
export default function StickyCta() {
  return (
    <div className="fixed inset-x-0 bottom-0 z-20 border-t border-trait bg-papier/95 px-4 pb-[max(0.75rem,env(safe-area-inset-bottom))] pt-3 md:hidden">
      <Link
        href="/analyse"
        className="flex min-h-14 w-full items-center justify-center rounded-xl bg-encre px-6 text-lg font-semibold text-papier active:translate-y-px"
      >
        Commencer, c'est gratuit
      </Link>
    </div>
  );
}
